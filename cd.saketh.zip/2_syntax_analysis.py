def syntax_check(values):
    # Syntax analysis placeholder
    return True