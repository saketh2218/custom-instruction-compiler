def generate_output(output_file, result):
    with open(output_file, 'w') as f:
        f.write(f"Result = {result}\n")
    print(f"Result = {result}")