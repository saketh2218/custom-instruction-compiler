def parse_input(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
        values = {}
        for line in lines:
            if '=' in line:
                var, val = line.strip().split('=')
                values[var.strip()] = float(val.strip())
        return values