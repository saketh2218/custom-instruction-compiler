import sys
from 1_lexical_analysis import parse_input
from 2_syntax_analysis import syntax_check
from 3_semantic_analysis import semantic_check
from 4_intermediate_code import fcomplex
from 5_code_generation import generate_output

if __name__ == "__main__":
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    vals = parse_input(input_file)
    syntax_check(vals)
    semantic_check(vals)
    result = fcomplex(vals['A'], vals['B'], vals['C'], vals['D'], vals['E'])
    generate_output(output_file, result)