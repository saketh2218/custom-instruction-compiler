def fcomplex(A, B, C, D, E):
    return (A * B) / (C * D) + E