def semantic_check(values):
    required = ['A', 'B', 'C', 'D', 'E']
    for key in required:
        if key not in values:
            raise ValueError(f"Missing variable: {key}")
    if values['C'] * values['D'] == 0:
        raise ZeroDivisionError("Denominator (C * D) cannot be zero")
    return True